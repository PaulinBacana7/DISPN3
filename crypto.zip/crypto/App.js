import React, { useState, useEffect } from 'react';
import { View, StyleSheet, Button, TextInput } from 'react-native';
import { Text } from 'react-native-elements';
import { Picker } from '@react-native-picker/picker'; 
import * as Location from 'expo-location';
import * as Calendar from 'expo-calendar';
import DateTimePickerModal from 'react-native-modal-datetime-picker'; 
import useWebSocket from 'react-use-websocket';

const availableCryptos = [
  { label: 'Bitcoin (BTC)', value: 'btcusdt' },
  { label: 'Ethereum (ETH)', value: 'ethusdt' },
  { label: 'Binance Coin (BNB)', value: 'bnbusdt' },
  { label: 'Cardano (ADA)', value: 'adausdt' },
  { label: 'Ripple (XRP)', value: 'xrpusdt' },
  { label: 'Polkadot (DOT)', value: 'dotusdt' },
];

const App = () => {
  
  const [selectedCrypto, setSelectedCrypto] = useState(availableCryptos[0].value);
  const [data, setData] = useState({});
  const [ location,setLocation] = useState(null);
  
  const [eventName, setEventName] = useState('');

  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);

  const [selectedDate, setSelectedDate] = useState(new Date());

  
  const getSignal = (value) => (value > 0 ? '+' : value < 0 ? '-' : '');

  
  const { lastJsonMessage } = useWebSocket(
    `wss://stream.binance.com:9443/ws/${selectedCrypto}@ticker`,
    {
      onMessage: (event) => {
        
        const message = JSON.parse(event.data);


        if (message) {
          setData({
            priceChange: parseFloat(message.p),
            priceChangePercent: parseFloat(message.P),
            close: message.c,
            high: message.h,
            low: message.l,
            quoteVolume: message.q,
          });
        }
      },
      onError: (event) => console.error('Erro no WebSocket:', event),
      shouldReconnect: () => true,
      reconnectInterval: 3000,
    }
  );


  const addEventToCalendar = async () => {
    try {
      
      const { status } = await Calendar.requestCalendarPermissionsAsync();
      if (status !== 'granted') {
        return;
      }

     
      const calendars = await Calendar.getCalendarsAsync();
      const targetCalendar = calendars[0]; 

  
      const eventDetails = {
        title: eventName || 'Evento Importante',
        startDate: selectedDate,
        endDate: new Date(selectedDate.getTime() + 60 * 60 * 1000),
        location: 'Local do Evento',
      };

      
      const eventId = await Calendar.createEventAsync(targetCalendar.id, eventDetails);

      console.log('Evento Adicionado, ID:', eventId);

     
      alert(`Evento adicionado ao calendário com ID: ${eventId}`);
    } catch (error) {
      console.error('Erro ao adicionar evento ao calendário:', error);
    }
  };

  
  const showDatePicker = () => {
    setDatePickerVisibility(true);
  };

 
  const hideDatePicker = () => {
    setDatePickerVisibility(false);
  };


  const handleDateConfirm = (date) => {
    hideDatePicker();
    setSelectedDate(date);
  };


  useEffect(() => {
    const requestLocationPermission = async () => {
      try {
      
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== 'granted') {
          console.log('Permissão de localização não concedida');
          return;
        }

        const locationResult = await Location.getCurrentPositionAsync({});
        setLocation(locationResult.coords);
      } catch (error) {
        console.error('Erro ao obter a localização:', error);
      }
    };

    requestLocationPermission();
  }, []); 
 
  return (
    <View style={styles.container}>
  <View style={styles.content}>
    <Text h1 style={styles.headerText}>
      CryptoTracker
    </Text>
    
    {}
      <Picker 
        selectedValue={selectedCrypto} onValueChange={(itemValue) => setSelectedCrypto(itemValue)} style={styles.picker}>

      {} 
      {availableCryptos.map((crypto) => (
        <Picker.Item key={crypto.value} label={crypto.label} value={crypto.value} />
      ))}
      </Picker>


          {[
      { label: 'Preço Atual', value: `R$ ${parseFloat(data.close).toFixed(2)}`, style: styles.price },
      
      { label: 'Alteração', value: `${getSignal(data.priceChange)} ${data.priceChange} (${getSignal(data.priceChangePercent)} ${data.priceChangePercent}%)`, style: styles.change },
      { label: 'Mínima 24h', value: data.low },
      { label: 'Máxima 24h', value: data.high },
    ].map((item, index) => (
      
      <View key={index} style={styles.line}>
        <Text style={styles.bold}>{item.label}: </Text>
        <Text style={item.style}>{item.value}</Text>
      </View>
    ))}

  </View>

  <View style={styles.calendario}>
    <TextInput style={styles.input} placeholder="Nome do Evento" alue={eventName} onChangeText={(text) => setEventName(text)}
    />
  </View>

  <View style={styles.buttonEscolherData}>
    <Button title="Escolher Data" onPress={showDatePicker} />
    <DateTimePickerModal isVisible={isDatePickerVisible} mode="datetime" onConfirm={handleDateConfirm} onCancel={hideDatePicker}
    />
  </View>

  <View style={styles.buttonbuttonAdicionarEvento}>
    <Button
      title="Adicionar Evento ao Calendário"
      onPress={addEventToCalendar}
    />
  </View>
</View>
  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    margin: 20,
    justifyContent: 'center',
  },
  content: {
    padding: 20,
    borderRadius: 10,
    marginBottom: 20,
    backgroundColor: '#fff',
    elevation: 5,
  },
  headerText: {
    marginBottom: 10,
    textAlign: 'center',
    color: '#333',
  },
  picker: {
    borderRadius: 5,
    marginBottom: 10,
    backgroundColor: '#eee',
  },
  line: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginHorizontal: 10,
    marginVertical: 10,
  },
  bold: {
    fontWeight: 'bold',
    color: '#555',
  },
  price: {
    color: '#27ae60',
  },
  change: {
    color: '#e74c3c',
  },
  calendario: {
    justifyContent: 'center',
    alignItems: 'center',
    marginVertical: 20,
  },
  input: {
    height: 40,
    borderWidth: 1,
    marginBottom: 10,
    paddingLeft: 10,
    borderRadius: 5,
    backgroundColor: '#fff',
  },
  buttonbuttonAdicionarEvento: {
    padding: 2,
    margin: 25,
  },
  buttonEscolherData: {
    margin: 25,
    padding: 2,
  },
});
export default App;
